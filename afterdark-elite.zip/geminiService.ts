
import { GoogleGenAI, Type } from "@google/genai";
import { GeminiResponse } from './types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getAIInsights = async (title: string, category: string, type: 'video' | 'photo'): Promise<GeminiResponse> => {
  try {
    const prompt = type === 'video' 
      ? `Provide an elegant, sophisticated description for an 18+ premium entertainment video titled "${title}" (category: "${category}"). Focus on the exclusive, high-end nature of the content. Also provide 3 luxury-themed tags.`
      : `Provide a poetic, artistic description for a high-end mature photography piece titled "${title}" (category: "${category}"). Focus on lighting, mood, and artistic aesthetic. Also provide 3 sophisticated tags.`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: {
              type: Type.STRING,
              description: 'A sophisticated description.',
            },
            tags: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '3 luxury tags.',
            },
          },
          required: ["summary", "tags"],
        },
      },
    });

    const jsonStr = response.text.trim();
    return JSON.parse(jsonStr) as GeminiResponse;
  } catch (error) {
    console.error("Error fetching AI insights:", error);
    return {
      summary: "Explore a realm of unparalleled sophistication and artistic depth designed for the discerning viewer.",
      tags: ["Elite", "Artistic", "18+"]
    };
  }
};

// Maintain backwards compatibility for existing imports if any
export const getVideoInsights = (title: string, category: string) => getAIInsights(title, category, 'video');
