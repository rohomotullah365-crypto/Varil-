
export interface Video {
  id: string;
  title: string;
  thumbnail: string;
  videoUrl: string;
  duration: string;
  views: string;
  category: string;
  description?: string;
}

export interface Photo {
  id: string;
  title: string;
  imageUrl: string;
  category: string;
  photographer: string;
}

export interface GeminiResponse {
  summary: string;
  tags: string[];
}
