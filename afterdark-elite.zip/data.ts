
import { Video, Photo } from './types';

export const MOCK_VIDEOS: Video[] = [
  {
    id: '1',
    title: 'Midnight in Manhattan: Exclusive Jazz Lounge',
    thumbnail: 'https://images.unsplash.com/photo-1514525253361-bee8718a300a?auto=format&fit=crop&q=80&w=600&h=400',
    videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
    duration: '15:20',
    views: '45K',
    category: 'Nightlife'
  },
  {
    id: '2',
    title: 'High Stakes: The World of Underground Poker',
    thumbnail: 'https://images.unsplash.com/photo-1511193311914-0346f16efe90?auto=format&fit=crop&q=80&w=600&h=400',
    videoUrl: 'https://www.w3schools.com/html/movie.mp4',
    duration: '22:10',
    views: '120K',
    category: 'Exclusive'
  },
  {
    id: '3',
    title: 'After Hours: The Secrets of Mixology',
    thumbnail: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&q=80&w=600&h=400',
    videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
    duration: '08:45',
    views: '89K',
    category: 'Lifestyle'
  },
  {
    id: '4',
    title: 'Noir Mystery: The Red Velvet Room',
    thumbnail: 'https://images.unsplash.com/photo-1485872222634-7a6792da6193?auto=format&fit=crop&q=80&w=600&h=400',
    videoUrl: 'https://www.w3schools.com/html/movie.mp4',
    duration: '45:00',
    views: '2.1M',
    category: 'Cinema'
  },
  {
    id: '5',
    title: 'Elite Clubbing: Ibiza Summer Season Opening',
    thumbnail: 'https://images.unsplash.com/photo-1541339907198-e08759dfc3ef?auto=format&fit=crop&q=80&w=600&h=400',
    videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
    duration: '12:30',
    views: '340K',
    category: 'Events'
  },
  {
    id: '6',
    title: 'The Art of the Tease: Modern Burlesque',
    thumbnail: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&q=80&w=600&h=400',
    videoUrl: 'https://www.w3schools.com/html/movie.mp4',
    duration: '18:55',
    views: '1.5M',
    category: 'Performance'
  }
];

export const MOCK_PHOTOS: Photo[] = [
  {
    id: 'p1',
    title: 'Crimson Elegance',
    imageUrl: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&q=80&w=800',
    category: 'Fashion',
    photographer: 'Elena Vance'
  },
  {
    id: 'p2',
    title: 'Shadow Play',
    imageUrl: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&q=80&w=800',
    category: 'Noir',
    photographer: 'Julian Black'
  },
  {
    id: 'p3',
    title: 'Velvet Midnight',
    imageUrl: 'https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&q=80&w=800',
    category: 'Boudoir',
    photographer: 'Sasha Rose'
  },
  {
    id: 'p4',
    title: 'Golden Hour Intrigue',
    imageUrl: 'https://images.unsplash.com/photo-1529139513465-492d7bbfe20d?auto=format&fit=crop&q=80&w=800',
    category: 'Portrait',
    photographer: 'Marcus Thorne'
  },
  {
    id: 'p5',
    title: 'Neon Lust',
    imageUrl: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&q=80&w=800',
    category: 'Aesthetic',
    photographer: 'Kai Nova'
  },
  {
    id: 'p6',
    title: 'Marble Silhouette',
    imageUrl: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?auto=format&fit=crop&q=80&w=800',
    category: 'Fine Art',
    photographer: 'Aria Sterling'
  }
];
