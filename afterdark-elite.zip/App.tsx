
import React, { useState, useEffect } from 'react';
import { Video, Photo } from './types';
import { MOCK_VIDEOS, MOCK_PHOTOS } from './data';
import VideoCard from './components/VideoCard';
import VideoModal from './components/VideoModal';
import PhotoCard from './components/PhotoCard';
import PhotoModal from './components/PhotoModal';
import Button from './components/Button';
import { Search, Flame, Crown, Bell, User, ShieldAlert, CheckCircle2, MoreVertical, LayoutGrid, Camera, Film } from 'lucide-react';

const App: React.FC = () => {
  const [videos] = useState<Video[]>(MOCK_VIDEOS);
  const [photos] = useState<Photo[]>(MOCK_PHOTOS);
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null);
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [isVerified, setIsVerified] = useState(false);
  const [viewMode, setViewMode] = useState<'cinema' | 'gallery'>('cinema');

  const videoCategories = ['All', 'Nightlife', 'Cinema', 'Performance', 'Exclusive', 'Events', 'Lifestyle'];
  const photoCategories = ['All', 'Fashion', 'Noir', 'Boudoir', 'Portrait', 'Aesthetic', 'Fine Art'];
  
  const currentCategories = viewMode === 'cinema' ? videoCategories : photoCategories;

  const filteredVideos = videos.filter(v => {
    const matchesCategory = activeCategory === 'All' || v.category === activeCategory;
    const matchesSearch = v.title.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const filteredPhotos = photos.filter(p => {
    const matchesCategory = activeCategory === 'All' || p.category === activeCategory;
    const matchesSearch = p.title.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  if (!isVerified) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center p-4 relative overflow-hidden">
        {/* Background Atmosphere */}
        <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-red-900/10 blur-[120px] rounded-full"></div>
        <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-[#D4AF37]/10 blur-[120px] rounded-full"></div>

        <div className="max-w-md w-full text-center space-y-8 animate-in zoom-in-95 duration-700 relative z-10">
          <div className="flex justify-center">
            <div className="w-20 h-20 bg-gradient-to-br from-[#D4AF37] to-[#8A6D3B] rounded-[2rem] flex items-center justify-center shadow-[0_0_50px_rgba(212,175,55,0.3)]">
              <Crown size={40} className="text-black" />
            </div>
          </div>
          
          <div className="space-y-4">
            <h1 className="text-4xl sm:text-5xl font-serif font-bold text-white tracking-tight">AfterDark Elite</h1>
            <p className="text-slate-400 font-light leading-relaxed">
              You are entering an <span className="text-[#D4AF37] font-semibold">Adult-Only</span> exclusive entertainment network. 
              Sophisticated content for mature viewers only.
            </p>
          </div>

          <div className="bg-slate-900/40 p-8 rounded-3xl border border-white/10 backdrop-blur-xl">
             <div className="flex items-center gap-3 text-red-500 mb-6 justify-center">
                <ShieldAlert size={20} />
                <span className="text-xs font-black uppercase tracking-widest">Mandatory Age Verification</span>
             </div>
             <div className="space-y-4">
                <Button variant="gold" className="w-full py-4 text-lg" onClick={() => setIsVerified(true)}>
                    I am 18+ (Enter Elite)
                </Button>
                <button 
                    className="w-full text-slate-500 hover:text-white transition-colors text-sm py-2"
                    onClick={() => window.location.href = 'https://google.com'}
                >
                    Exit Site
                </button>
             </div>
          </div>
          
          <p className="text-[10px] text-slate-600 uppercase tracking-[0.2em]">
            Protected by AfterDark Encryption &copy; 2025
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-slate-200 flex flex-col selection:bg-[#D4AF37] selection:text-black">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-black/80 backdrop-blur-2xl border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <div className="flex items-center gap-3 cursor-pointer group">
              <div className="w-10 h-10 bg-gradient-to-br from-[#D4AF37] to-[#B8860B] rounded-xl flex items-center justify-center group-hover:rotate-6 transition-all shadow-[0_0_20px_rgba(212,175,55,0.2)]">
                <Crown size={22} className="text-black" />
              </div>
              <span className="text-xl sm:text-2xl font-serif font-bold tracking-tight text-white">
                AfterDark<span className="text-[#D4AF37]">Elite</span>
              </span>
            </div>

            {/* Main Toggle */}
            <div className="hidden md:flex items-center bg-slate-900/50 rounded-full p-1 border border-white/5">
               <button 
                onClick={() => { setViewMode('cinema'); setActiveCategory('All'); }}
                className={`flex items-center gap-2 px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'cinema' ? 'bg-[#D4AF37] text-black' : 'text-slate-400 hover:text-white'}`}
               >
                 <Film size={14} />
                 Cinema
               </button>
               <button 
                onClick={() => { setViewMode('gallery'); setActiveCategory('All'); }}
                className={`flex items-center gap-2 px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'gallery' ? 'bg-[#D4AF37] text-black' : 'text-slate-400 hover:text-white'}`}
               >
                 <Camera size={14} />
                 Gallery
               </button>
            </div>

            {/* Utility Icons */}
            <div className="flex items-center gap-2 sm:gap-6">
              <button className="p-2.5 hover:bg-white/5 rounded-full text-slate-400 hover:text-white transition-all">
                <Bell size={20} />
              </button>
              <button className="bg-white/5 border border-white/10 hover:border-[#D4AF37]/50 p-2.5 rounded-xl transition-all group">
                <User size={20} className="group-hover:text-[#D4AF37]" />
              </button>
              <button className="lg:hidden p-2 text-slate-400">
                <MoreVertical size={24} />
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-16">
        
        {/* Hero Section */}
        <div className="mb-16 text-center lg:text-left flex flex-col lg:flex-row lg:items-end justify-between gap-8">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-[10px] font-black tracking-[0.3em] text-[#D4AF37] mb-6">
                <Flame size={14} className="animate-bounce" />
                {viewMode === 'cinema' ? 'LATEST CINEMATIC RELEASES' : 'CURATED ARTISTIC GALLERY'}
            </div>
            <h1 className="text-5xl sm:text-7xl font-serif font-bold mb-6 tracking-tight leading-none text-white">
                {viewMode === 'cinema' ? 'After-Hours Cinema.' : 'Elite Photography.'}
            </h1>
            <p className="text-slate-400 text-lg sm:text-xl font-light max-w-2xl leading-relaxed">
                {viewMode === 'cinema' 
                  ? 'Unlock our curated selection of late-night noir, premium nightlife tours, and exclusive performances.'
                  : 'A refined collection of artistic mature-themed photography, focusing on composition, lighting, and sophisticated aesthetics.'}
            </p>
          </div>
        </div>

        {/* Categories Bar */}
        <div className="mb-12 sticky top-[81px] z-40 bg-black/50 backdrop-blur-sm py-4 -mx-4 px-4">
          <div className="flex items-center gap-3 overflow-x-auto scrollbar-hide">
            <LayoutGrid className="text-slate-700 mr-2 flex-shrink-0" size={20} />
            {currentCategories.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`whitespace-nowrap px-8 py-2.5 rounded-full text-xs font-bold uppercase tracking-[0.2em] transition-all duration-300 border ${
                  activeCategory === cat 
                  ? 'bg-[#D4AF37] border-[#D4AF37] text-black shadow-[0_5px_20px_rgba(212,175,55,0.2)]' 
                  : 'bg-transparent border-white/5 text-slate-500 hover:text-white hover:border-white/20'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Content Section Header */}
        <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
                <div className="h-10 w-1 bg-[#D4AF37]"></div>
                <h3 className="text-2xl font-serif font-bold text-white uppercase tracking-wider">
                  {viewMode === 'cinema' ? 'Premium Vault' : 'Artistic Showcase'}
                </h3>
            </div>
            <div className="relative group max-w-xs w-full hidden sm:block">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600" size={14} />
                <input 
                  type="text" 
                  placeholder="Filter collection..."
                  className="w-full bg-white/5 border border-white/10 rounded-lg py-2 pl-10 pr-4 text-[10px] focus:outline-none focus:border-[#D4AF37]/50"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
            </div>
        </div>

        {/* Grid Display */}
        {viewMode === 'cinema' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 sm:gap-12 animate-in slide-in-from-bottom-4 duration-700">
            {filteredVideos.map((video) => (
              <VideoCard 
                key={video.id} 
                video={video} 
                onWatch={(v) => setSelectedVideo(v)}
                onDownload={() => alert("Exclusive Members Only Access Required.")}
              />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 sm:gap-10 animate-in slide-in-from-bottom-4 duration-700">
            {filteredPhotos.map((photo) => (
              <PhotoCard 
                key={photo.id} 
                photo={photo} 
                onClick={(p) => setSelectedPhoto(p)}
              />
            ))}
          </div>
        )}

        {((viewMode === 'cinema' && filteredVideos.length === 0) || (viewMode === 'gallery' && filteredPhotos.length === 0)) && (
          <div className="text-center py-32 border-2 border-dashed border-white/5 rounded-[3rem]">
            <Crown className="mx-auto text-slate-800 mb-6" size={80} strokeWidth={1} />
            <h3 className="text-2xl font-serif text-slate-500">The Vault is empty</h3>
            <p className="text-slate-600 font-light mt-2 tracking-wide">Try adjusting your elite filters.</p>
          </div>
        )}
      </main>

      {/* Luxury Footer */}
      <footer className="bg-black border-t border-white/5 py-24 px-4 overflow-hidden relative">
        <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-[#D4AF37]/5 blur-[100px] rounded-full"></div>
        <div className="max-w-7xl mx-auto relative z-10">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-16 mb-20 text-center md:text-left">
                <div className="md:col-span-2">
                    <div className="flex items-center gap-3 justify-center md:justify-start mb-8">
                        <div className="w-12 h-12 bg-gradient-to-br from-[#D4AF37] to-[#8A6D3B] rounded-2xl flex items-center justify-center">
                            <Crown size={24} className="text-black" />
                        </div>
                        <span className="text-3xl font-serif font-bold tracking-tighter text-white">
                            AfterDark<span className="text-[#D4AF37]">Elite</span>
                        </span>
                    </div>
                    <p className="text-slate-500 text-lg font-light leading-relaxed max-w-sm mx-auto md:mx-0">
                        Defining the gold standard for mature digital entertainment. Experience the exceptional.
                    </p>
                </div>
                <div>
                    <h4 className="font-bold text-[#D4AF37] mb-8 uppercase tracking-[0.3em] text-xs">The Collection</h4>
                    <ul className="text-slate-500 text-sm space-y-4 font-medium uppercase tracking-widest">
                        <li className="hover:text-white cursor-pointer transition-colors" onClick={() => setViewMode('cinema')}>Midnight Cinema</li>
                        <li className="hover:text-white cursor-pointer transition-colors" onClick={() => setViewMode('gallery')}>Artistic Gallery</li>
                        <li className="hover:text-white cursor-pointer transition-colors">Exclusive Lounge</li>
                    </ul>
                </div>
                <div>
                    <h4 className="font-bold text-[#D4AF37] mb-8 uppercase tracking-[0.3em] text-xs">Membership</h4>
                    <ul className="text-slate-500 text-sm space-y-4 font-medium uppercase tracking-widest">
                        <li className="hover:text-white cursor-pointer transition-colors">Concierge</li>
                        <li className="hover:text-white cursor-pointer transition-colors">Privacy Policy</li>
                        <li className="hover:text-white cursor-pointer transition-colors">Support</li>
                    </ul>
                </div>
            </div>
            <div className="flex flex-col md:flex-row items-center justify-between pt-12 border-t border-white/5 text-[10px] font-black uppercase tracking-[0.4em] text-slate-700">
                <p>&copy; 2025 AfterDark Elite Media Group</p>
            </div>
        </div>
      </footer>

      {/* Modals */}
      {selectedVideo && (
        <VideoModal 
          video={selectedVideo} 
          onClose={() => setSelectedVideo(null)} 
        />
      )}
      {selectedPhoto && (
        <PhotoModal 
          photo={selectedPhoto} 
          onClose={() => setSelectedPhoto(null)} 
        />
      )}
    </div>
  );
};

export default App;
