
import React, { useEffect, useState } from 'react';
import { Video, GeminiResponse } from '../types';
import { X, Share2, Star, Heart, Loader2, Sparkles, ShieldCheck } from 'lucide-react';
import { getVideoInsights } from '../geminiService';
import Button from './Button';

interface VideoModalProps {
  video: Video;
  onClose: () => void;
}

const VideoModal: React.FC<VideoModalProps> = ({ video, onClose }) => {
  const [insights, setInsights] = useState<GeminiResponse | null>(null);
  const [loadingInsights, setLoadingInsights] = useState(true);

  useEffect(() => {
    const fetchAI = async () => {
      setLoadingInsights(true);
      const data = await getVideoInsights(video.title, video.category);
      setInsights(data);
      setLoadingInsights(false);
    };
    fetchAI();
  }, [video]);

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-2 sm:p-6 bg-black/95 backdrop-blur-xl animate-in fade-in duration-500">
      <div className="bg-black w-full max-w-5xl max-h-[95vh] rounded-3xl overflow-hidden flex flex-col shadow-[0_0_100px_rgba(212,175,55,0.1)] border border-white/10 relative">
        
        {/* Header Overlay */}
        <div className="absolute top-0 left-0 right-0 z-10 p-6 flex items-center justify-between bg-gradient-to-b from-black/80 to-transparent">
          <div className="flex items-center gap-3">
            <div className="bg-red-600 px-2 py-0.5 rounded text-[10px] font-black text-white">18+</div>
            <h2 className="text-xl font-serif text-white drop-shadow-lg">{video.title}</h2>
          </div>
          <button 
            onClick={onClose}
            className="p-3 bg-white/10 hover:bg-[#D4AF37] hover:text-black rounded-full transition-all text-white backdrop-blur-md"
          >
            <X size={24} />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto">
          {/* Video Player */}
          <div className="aspect-video bg-black flex items-center justify-center border-b border-white/5">
            <video 
              src={video.videoUrl} 
              controls 
              autoPlay 
              className="w-full h-full max-h-[70vh]"
            />
          </div>

          <div className="p-8 sm:p-12">
            {/* AI Insights Section */}
            <div className="relative p-8 rounded-3xl bg-gradient-to-br from-slate-900 to-black border border-[#D4AF37]/20 mb-8 overflow-hidden group">
              <div className="absolute -top-10 -right-10 w-40 h-40 bg-[#D4AF37]/10 blur-3xl rounded-full"></div>
              
              <div className="flex items-center gap-3 mb-4 text-[#D4AF37]">
                <Sparkles size={20} />
                <h3 className="text-xs font-black uppercase tracking-[0.3em]">AI Critic Review</h3>
              </div>
              
              {loadingInsights ? (
                <div className="flex items-center gap-3 text-slate-500 py-4">
                  <Loader2 className="animate-spin" size={20} />
                  <span className="text-sm font-medium">Curating exclusive commentary...</span>
                </div>
              ) : (
                <div className="animate-in fade-in duration-700">
                  <p className="text-slate-300 text-lg sm:text-xl font-light leading-relaxed mb-6 italic">
                    "{insights?.summary}"
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {insights?.tags.map((tag, i) => (
                      <span key={i} className="text-[10px] px-3 py-1 bg-[#D4AF37]/10 text-[#D4AF37] rounded-full border border-[#D4AF37]/20 uppercase font-bold tracking-widest">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-start">
              <div className="space-y-6">
                 <div className="flex items-center gap-6">
                    <div className="flex flex-col items-center gap-1 group cursor-pointer">
                        <div className="p-4 rounded-full border border-white/10 group-hover:bg-red-900/20 group-hover:border-red-800 transition-all">
                            <Heart size={24} className="text-slate-400 group-hover:text-red-500" />
                        </div>
                        <span className="text-[10px] text-slate-500 uppercase font-bold">Lust</span>
                    </div>
                    <div className="flex flex-col items-center gap-1 group cursor-pointer">
                        <div className="p-4 rounded-full border border-white/10 group-hover:bg-[#D4AF37]/20 group-hover:border-[#D4AF37] transition-all">
                            <Star size={24} className="text-slate-400 group-hover:text-[#D4AF37]" />
                        </div>
                        <span className="text-[10px] text-slate-500 uppercase font-bold">Rate</span>
                    </div>
                    <div className="flex flex-col items-center gap-1 group cursor-pointer">
                        <div className="p-4 rounded-full border border-white/10 group-hover:bg-blue-900/20 group-hover:border-blue-800 transition-all">
                            <Share2 size={24} className="text-slate-400 group-hover:text-blue-400" />
                        </div>
                        <span className="text-[10px] text-slate-500 uppercase font-bold">Send</span>
                    </div>
                 </div>

                 <p className="text-slate-400 text-base leading-loose">
                    This premium selection, part of our <span className="text-[#D4AF37]">Elite {video.category} Collection</span>, offers a deep dive into sophisticated mature-themed entertainment. Currently being viewed by hundreds of elite members, this content remains under our strict <span className="text-white font-bold">AfterDark Security Protocol</span>.
                 </p>
              </div>

              <div className="bg-slate-900/40 p-6 rounded-2xl border border-white/5 flex flex-col gap-4">
                <div className="flex items-center gap-3 mb-2">
                    <ShieldCheck size={20} className="text-[#D4AF37]" />
                    <span className="text-sm font-bold uppercase tracking-widest">Protected Access</span>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed">
                    Accessing this video implies acceptance of our 18+ Mature Content Agreement. Screen recording or unauthorized distribution will result in immediate termination of membership.
                </p>
                <Button variant="gold" className="mt-4">Download HQ Master</Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoModal;
