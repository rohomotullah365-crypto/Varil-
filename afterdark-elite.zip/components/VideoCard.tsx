
import React from 'react';
import { Video } from '../types';
import Button from './Button';
import { Play, Shield, Eye, Clock, Crown } from 'lucide-react';

interface VideoCardProps {
  video: Video;
  onWatch: (video: Video) => void;
  onDownload: (video: Video) => void;
}

const VideoCard: React.FC<VideoCardProps> = ({ video, onWatch, onDownload }) => {
  return (
    <div className="bg-gradient-to-b from-slate-900/40 to-black border border-white/5 rounded-2xl overflow-hidden hover:border-[#D4AF37]/40 transition-all duration-500 group flex flex-col h-full shadow-2xl">
      {/* Thumbnail Container */}
      <div 
        className="relative aspect-[16/10] overflow-hidden cursor-pointer group"
        onClick={() => onWatch(video)}
      >
        <img 
          src={video.thumbnail} 
          alt={video.title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 filter brightness-75 group-hover:brightness-100"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/20 opacity-60 group-hover:opacity-40 transition-opacity"></div>
        
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="w-16 h-16 bg-[#D4AF37]/90 backdrop-blur rounded-full flex items-center justify-center shadow-2xl transform scale-90 group-hover:scale-100 transition-transform">
            <Play fill="black" className="text-black ml-1" size={28} />
          </div>
        </div>

        <div className="absolute top-3 left-3 flex gap-2">
           <div className="bg-black/80 backdrop-blur-md px-2 py-1 rounded text-[10px] uppercase font-bold text-[#D4AF37] border border-[#D4AF37]/30 flex items-center gap-1">
            <Crown size={12} />
            {video.category}
          </div>
          <div className="bg-red-600/90 px-2 py-1 rounded text-[10px] uppercase font-black text-white tracking-widest">
            18+
          </div>
        </div>
        
        <div className="absolute bottom-3 right-3 bg-black/80 backdrop-blur px-2 py-0.5 rounded text-[10px] font-mono text-slate-300 border border-white/10">
          {video.duration}
        </div>
      </div>

      {/* Content */}
      <div className="p-5 flex-grow flex flex-col">
        <h3 className="text-xl font-serif font-bold text-white mb-2 leading-tight group-hover:text-[#D4AF37] transition-colors line-clamp-2">
          {video.title}
        </h3>
        
        <div className="flex items-center gap-3 text-slate-500 text-xs mb-6">
          <span className="flex items-center gap-1">
            <Eye size={12} />
            {video.views} viewers
          </span>
          <span className="w-1 h-1 bg-slate-800 rounded-full"></span>
          <span className="flex items-center gap-1 text-slate-400 font-semibold italic">
            <Shield size={12} className="text-[#D4AF37]" />
            Elite Membership Only
          </span>
        </div>

        {/* Actions */}
        <div className="flex flex-col gap-2 mt-auto">
          <Button 
            variant="gold" 
            onClick={() => onWatch(video)}
            className="w-full"
            icon={<Play size={18} />}
          >
            Enter Now
          </Button>
          <button className="text-[10px] text-center uppercase tracking-[0.2em] font-bold text-slate-600 hover:text-white transition-colors py-2">
            Add to Private Collection
          </button>
        </div>
      </div>
    </div>
  );
};

export default VideoCard;
