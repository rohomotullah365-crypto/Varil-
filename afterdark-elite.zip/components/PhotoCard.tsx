
import React from 'react';
import { Photo } from '../types';
import { Maximize2, Camera, Heart } from 'lucide-react';

interface PhotoCardProps {
  photo: Photo;
  onClick: (photo: Photo) => void;
}

const PhotoCard: React.FC<PhotoCardProps> = ({ photo, onClick }) => {
  return (
    <div 
      className="group relative bg-slate-900 rounded-2xl overflow-hidden cursor-pointer border border-white/5 hover:border-[#D4AF37]/40 transition-all duration-700 shadow-2xl aspect-[3/4]"
      onClick={() => onClick(photo)}
    >
      <img 
        src={photo.imageUrl} 
        alt={photo.title}
        className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110 filter brightness-[0.85] group-hover:brightness-100"
      />
      
      {/* Overlays */}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/20 opacity-60 group-hover:opacity-40 transition-opacity"></div>
      
      <div className="absolute top-4 left-4 flex gap-2">
        <div className="bg-black/60 backdrop-blur-md px-2 py-1 rounded text-[10px] uppercase font-black text-[#D4AF37] border border-[#D4AF37]/20 flex items-center gap-1">
          <Camera size={12} />
          {photo.category}
        </div>
        <div className="bg-red-600/90 px-2 py-1 rounded text-[10px] uppercase font-black text-white tracking-widest">
          18+
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 p-6 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
        <h3 className="text-xl font-serif font-bold text-white mb-1 drop-shadow-lg">{photo.title}</h3>
        <p className="text-xs text-slate-400 font-medium italic mb-4">By {photo.photographer}</p>
        
        <div className="flex items-center justify-between">
           <div className="flex gap-4">
              <Heart size={18} className="text-slate-400 hover:text-red-500 transition-colors" />
              <Maximize2 size={18} className="text-slate-400 hover:text-[#D4AF37] transition-colors" />
           </div>
           <span className="text-[10px] font-bold text-[#D4AF37] uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">
             View Art
           </span>
        </div>
      </div>
    </div>
  );
};

export default PhotoCard;
