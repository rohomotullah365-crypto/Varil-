
import React from 'react';

interface ButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
  variant?: 'primary' | 'secondary' | 'danger' | 'gold';
  icon?: React.ReactNode;
}

const Button: React.FC<ButtonProps> = ({ children, onClick, className = '', variant = 'primary', icon }) => {
  const baseStyles = "flex items-center justify-center gap-2 px-4 py-2 rounded-lg font-semibold transition-all duration-300 transform active:scale-95 text-sm sm:text-base tracking-wide border";
  
  const variants = {
    primary: "bg-transparent border-white/20 hover:border-white text-white hover:bg-white/10",
    secondary: "bg-white text-black border-white hover:bg-slate-200",
    danger: "bg-red-900/20 border-red-800 text-red-400 hover:bg-red-800/40",
    gold: "bg-[#D4AF37] border-[#D4AF37] text-black hover:bg-[#B89600] shadow-lg shadow-[#D4AF37]/20"
  };

  return (
    <button 
      onClick={onClick}
      className={`${baseStyles} ${variants[variant]} ${className}`}
    >
      {icon}
      {children}
    </button>
  );
};

export default Button;
