
import React, { useEffect, useState } from 'react';
import { Photo, GeminiResponse } from '../types';
import { X, Download, Share2, Heart, Sparkles, Loader2, ShieldAlert } from 'lucide-react';
import { getAIInsights } from '../geminiService';
import Button from './Button';

interface PhotoModalProps {
  photo: Photo;
  onClose: () => void;
}

const PhotoModal: React.FC<PhotoModalProps> = ({ photo, onClose }) => {
  const [insights, setInsights] = useState<GeminiResponse | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      setLoading(true);
      const data = await getAIInsights(photo.title, photo.category, 'photo');
      setInsights(data);
      setLoading(false);
    };
    fetch();
  }, [photo]);

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-2 sm:p-4 bg-black/98 backdrop-blur-2xl animate-in fade-in duration-500">
      <div className="relative w-full max-w-6xl h-full max-h-[95vh] flex flex-col md:flex-row bg-black rounded-[2rem] overflow-hidden border border-white/10 shadow-[0_0_80px_rgba(212,175,55,0.1)]">
        
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 z-50 p-3 bg-black/40 hover:bg-[#D4AF37] hover:text-black rounded-full transition-all text-white backdrop-blur-xl border border-white/10"
        >
          <X size={24} />
        </button>

        {/* Image Section */}
        <div className="flex-grow bg-slate-950 flex items-center justify-center overflow-hidden p-4">
           <img 
            src={photo.imageUrl} 
            alt={photo.title}
            className="max-w-full max-h-full object-contain rounded-lg shadow-2xl animate-in zoom-in-95 duration-700"
           />
        </div>

        {/* Sidebar Info */}
        <div className="w-full md:w-[400px] flex flex-col bg-slate-900/50 border-l border-white/5 p-8 overflow-y-auto">
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-2">
                <span className="bg-red-600 px-2 py-0.5 rounded text-[10px] font-black text-white">ADULT 18+</span>
                <span className="text-[#D4AF37] text-xs font-bold uppercase tracking-widest">Artistic Series</span>
            </div>
            <h2 className="text-3xl font-serif font-bold text-white mb-2">{photo.title}</h2>
            <p className="text-slate-400 text-sm italic">Masterpiece by {photo.photographer}</p>
          </div>

          <div className="space-y-8">
            {/* AI Commentary */}
            <div className="p-6 rounded-2xl bg-[#D4AF37]/5 border border-[#D4AF37]/10 relative overflow-hidden">
               <div className="flex items-center gap-2 mb-4 text-[#D4AF37]">
                <Sparkles size={16} />
                <span className="text-[10px] font-black uppercase tracking-[0.2em]">Curator's Note</span>
               </div>
               {loading ? (
                 <div className="flex items-center gap-2 text-slate-500 py-4">
                    <Loader2 size={16} className="animate-spin" />
                    <span className="text-xs">Analyzing composition...</span>
                 </div>
               ) : (
                 <div className="animate-in fade-in duration-700">
                    <p className="text-slate-300 text-sm leading-relaxed mb-6 font-light italic">"{insights?.summary}"</p>
                    <div className="flex flex-wrap gap-2">
                        {insights?.tags.map((tag, i) => (
                          <span key={i} className="text-[9px] px-2 py-1 bg-white/5 text-slate-400 rounded-md border border-white/5 uppercase font-bold tracking-widest">#{tag}</span>
                        ))}
                    </div>
                 </div>
               )}
            </div>

            {/* Interaction */}
            <div className="flex justify-between items-center py-4 border-y border-white/5">
                <div className="flex gap-6">
                    <button className="flex flex-col items-center gap-1 group">
                        <Heart className="text-slate-500 group-hover:text-red-500 transition-colors" size={20} />
                        <span className="text-[9px] text-slate-600 font-bold uppercase">Save</span>
                    </button>
                    <button className="flex flex-col items-center gap-1 group">
                        <Share2 className="text-slate-500 group-hover:text-blue-400 transition-colors" size={20} />
                        <span className="text-[9px] text-slate-600 font-bold uppercase">Share</span>
                    </button>
                </div>
                <div className="flex items-center gap-2 text-slate-500">
                    <ShieldAlert size={14} className="text-[#D4AF37]" />
                    <span className="text-[10px] font-bold uppercase tracking-tighter">Elite Only Access</span>
                </div>
            </div>

            <div className="space-y-4">
                <Button variant="gold" className="w-full" icon={<Download size={18} />}>
                    Secure Download (RAW)
                </Button>
                <p className="text-[10px] text-slate-600 text-center leading-relaxed">
                    This artistic photography is part of the private collection. Redistribution is strictly prohibited under the membership agreement.
                </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PhotoModal;
